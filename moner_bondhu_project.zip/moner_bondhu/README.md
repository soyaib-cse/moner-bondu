# মনের বন্ধু — Setup Guide

## ফোল্ডার স্ট্রাকচার
```
moner_bondhu/
├── server.js          ← Backend (API key এখানে)
├── package.json       ← Dependencies
└── public/
    └── index.html     ← Frontend (সব design এখানে)
```

---

## ধাপ ১ — Node.js ইন্সটল করো
https://nodejs.org থেকে LTS version ডাউনলোড করো

## ধাপ ২ — API Key বসাও
`server.js` ফাইল খুলে এই লাইনটা বদলাও:
```js
const ANTHROPIC_API_KEY = "YOUR_API_KEY_HERE";
// এটা হবে:
const ANTHROPIC_API_KEY = "sk-ant-api03-তোমার-real-key";
```
API Key পাবে: https://console.anthropic.com/settings/keys

## ধাপ ৩ — Dependencies ইন্সটল করো
Terminal বা Command Prompt খুলে:
```bash
cd moner_bondhu
npm install
```

## ধাপ ৪ — Server চালাও
```bash
node server.js
```
দেখবে: ✅ Server চলছে: http://localhost:3000

## ধাপ ৫ — Browser-এ খোলো
http://localhost:3000

---

## Modify করার গাইড

### App নাম/রং বদলাতে
`public/index.html` এর উপরে CONFIG অংশ বদলাও

### AI-র ব্যবহার বদলাতে
CONFIG-এর `SYSTEM_PROMPT` বদলাও

### Hotline নম্বর বদলাতে
CONFIG-এর `HOTLINES` array বদলাও

---

## Online Deploy করতে (Render.com — Free)
1. https://render.com এ account খোলো
2. New Web Service → GitHub repo connect করো
3. Environment Variable তে বসাও:
   - Key: `ANTHROPIC_API_KEY`
   - Value: তোমার API key
4. Start Command: `node server.js`
